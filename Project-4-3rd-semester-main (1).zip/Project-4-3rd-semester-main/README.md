# Project-4-3rd-semester

This project is about a sss..smarthome for reptiles 🐍

"Sssmart Home Local" contains website files.

"Sssmarthome_esp" contains C-code for Arduino
